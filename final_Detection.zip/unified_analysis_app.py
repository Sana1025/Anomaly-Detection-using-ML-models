import sys
import os
import pandas as pd
import numpy as np

# Import all necessary machine learning models and tools from scikit-learn
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler # Used to normalize data for certain models

# Import necessary components from the PyQt6 library for the Graphical User Interface (GUI)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QPushButton, QLabel, QFileDialog, QMessageBox, QComboBox,
    QGroupBox, QStackedWidget, QTextBrowser
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt # The Qt object holds core enums like alignment flags

# Import Matplotlib components to embed plots directly into the PyQt6 application
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# ==============================================================================
# SECTION 1: MAIN APPLICATION STRUCTURE AND CONTROLLER
# ==============================================================================

# The AppController is the main window of our application. It controls which page is visible.
class AppController(QMainWindow):
    def __init__(self):
        # Standard setup for the main window
        super().__init__()
        self.setWindowTitle("Multi-Model Analysis Hub")
        self.setGeometry(100, 100, 950, 800) # Set window position and size

        # The QStackedWidget is like a deck of cards, where each card is a page (screen).
        # We can show only one page at a time.
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget) # Make the stacked widget fill the main window
        
        # A dictionary to hold references to all our page instances
        self.pages = {}
        # List of all page classes that need to be created
        page_classes = [
            HomePage, DetectionMethodPage, ExplorerPage,
            VisualizeLoadPage, VisualizeSelectPage, VisualizePlotPage
        ]
        
        # Loop through the page classes, create an instance of each, and add it to the QStackedWidget
        for PageClass in page_classes:
            page = PageClass(self) # Pass a reference to this controller to each page
            self.stacked_widget.addWidget(page)
            self.pages[PageClass.__name__] = page # Store the page instance for later access
            
        self.show_page('HomePage') # Set the initial visible page
        self.reset_state() # Initialize the application's shared data

    # A central place to store shared data between pages (like the loaded dataframe)
    def reset_state(self):
        self.app_state = {
            "interactive_model": None,  # e.g., 'lof', 'svm', 'dbscan'
            "dataframe": None,          # The loaded pandas DataFrame
            "vis_x_col": None,          # The selected X-axis column for visualization
            "vis_y_col": None,          # The selected Y-axis column for visualization
        }

    # Switches the visible page in the QStackedWidget
    def show_page(self, page_name: str):
        self.stacked_widget.setCurrentWidget(self.pages[page_name])
        # If the page has an 'on_show' method, call it. This is useful for refreshing a page's content.
        current_page = self.stacked_widget.currentWidget()
        if hasattr(current_page, 'on_show'):
            current_page.on_show()

# BasePage is a template for all other pages. It ensures every page has a reference
# to the AppController, so they can switch pages or access shared data.
class BasePage(QWidget):
    def __init__(self, controller: AppController):
        super().__init__(controller)
        self.controller = controller # Store the controller reference
        self.setFont(QFont("Arial", 11)) # Set a default font for all pages

# ==============================================================================
# SECTION 2: APPLICATION PAGES
# ==============================================================================

# --- PAGE 1: The initial welcome screen ---
class HomePage(BasePage):
    def __init__(self, controller):
        super().__init__(controller)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter) # Center all widgets vertically
        
        # Create UI elements
        title = QLabel("Analysis Hub")
        title.setFont(QFont("Arial", 24, QFont.Weight.Bold))
        
        detection_button = QPushButton("🔍 Find Anomalies Interactively")
        detection_button.clicked.connect(lambda: self.controller.show_page('DetectionMethodPage'))
        
        visualize_button = QPushButton("📊 Just Visualize Data")
        visualize_button.clicked.connect(lambda: self.controller.show_page('VisualizeLoadPage'))
        
        # Style the main buttons
        for btn in [detection_button, visualize_button]:
            btn.setFixedSize(350, 60)
        
        # Add widgets and spacing to the layout
        layout.addStretch()
        layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(detection_button, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(visualize_button, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addStretch()

# --- PAGE 2: Lets the user choose which anomaly detection model to use ---
class DetectionMethodPage(BasePage):
    def __init__(self, controller):
        super().__init__(controller)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("Choose an Interactive Model")
        title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        
        # Create a button for each model
        lof_button = QPushButton("Analyze with LOF")
        lof_button.clicked.connect(lambda: self.start_analysis('lof'))
        
        svm_button = QPushButton("Analyze with One-Class SVM")
        svm_button.clicked.connect(lambda: self.start_analysis('svm'))

        dbscan_button = QPushButton("Analyze with DBSCAN")
        dbscan_button.clicked.connect(lambda: self.start_analysis('dbscan'))
        
        back_button = QPushButton("Back to Home")
        back_button.clicked.connect(lambda: self.controller.show_page('HomePage'))

        # Style the model buttons
        for btn in [lof_button, svm_button, dbscan_button]:
            btn.setFixedSize(300, 60)

        # Add widgets to the layout
        layout.addStretch()
        layout.addWidget(title)
        layout.addWidget(lof_button)
        layout.addWidget(svm_button)
        layout.addWidget(dbscan_button)
        layout.addStretch()
        # Align the back button to the bottom-left corner
        layout.addWidget(back_button, alignment=Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)

    # Stores the chosen model in the app state and switches to the main explorer page
    def start_analysis(self, model_name):
        self.controller.app_state['interactive_model'] = model_name
        self.controller.show_page('ExplorerPage')

# --- PAGE 3: The main tool for interactive anomaly detection and explanation ---
class ExplorerPage(BasePage):
    def __init__(self, controller):
        super().__init__(controller)
        self.dataframe = None # This page holds its own copy of the dataframe
        main_layout = QVBoxLayout(self)

        self.title_label = QLabel("Interactive Explorer")
        self.title_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        
        # Organize the UI into logical groups
        control_panel = QGroupBox("Controls")
        plot_panel = QGroupBox("Visualization")
        explanation_panel = QGroupBox("Explanations")
        
        # Add the groups to the main layout
        main_layout.addWidget(self.title_label)
        main_layout.addWidget(control_panel)
        main_layout.addWidget(plot_panel, 2)      # Give the plot more vertical space
        main_layout.addWidget(explanation_panel, 1) # Give the explanation less space
        
        # Call helper methods to create the content of each panel
        self.setup_ui(control_panel, plot_panel, explanation_panel)

    # This method is called every time the page becomes visible
    def on_show(self):
        # Get the selected model from the app state and update the title
        model_name = self.controller.app_state.get('interactive_model', 'Unknown')
        self.title_label.setText(f"Interactive {model_name.upper()} Explorer")
        
        # Clear any results from a previous run
        self.figure.clear()
        self.canvas.draw()
        self.results_label.setText("Load a file and select features to begin.")
        self.explanation_browser.setText("")

    # Helper method to create all the widgets inside the panels
    def setup_ui(self, controls, plots, explanations):
        # Create controls
        c_layout = QVBoxLayout(controls)
        load_btn = QPushButton("Load CSV File"); load_btn.clicked.connect(self.load_csv)
        self.file_label = QLabel("No file loaded.")
        self.x_combo = QComboBox(); self.y_combo = QComboBox() # Dropdown menus
        run_btn = QPushButton("Run Analysis"); run_btn.clicked.connect(self.run_analysis)
        back_btn = QPushButton("Back to Model Selection"); back_btn.clicked.connect(lambda: self.controller.show_page('DetectionMethodPage'))
        c_layout.addWidget(load_btn); c_layout.addWidget(self.file_label); c_layout.addWidget(QLabel("X-Axis Feature:")); c_layout.addWidget(self.x_combo)
        c_layout.addWidget(QLabel("Y-Axis Feature:")); c_layout.addWidget(self.y_combo); c_layout.addWidget(run_btn); c_layout.addStretch(); c_layout.addWidget(back_btn)
        
        # Create plot area
        p_layout = QVBoxLayout(plots)
        self.figure = Figure(); self.canvas = FigureCanvas(self.figure); self.results_label = QLabel()
        p_layout.addWidget(self.results_label); p_layout.addWidget(self.canvas)
        
        # Create explanation area
        e_layout = QVBoxLayout(explanations)
        self.explanation_browser = QTextBrowser(); e_layout.addWidget(self.explanation_browser)

    # Handles loading the CSV file
    def load_csv(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "*.csv")
        if not file_path: return # User cancelled
        try:
            self.dataframe = pd.read_csv(file_path)
            self.file_label.setText(f"Loaded: {os.path.basename(file_path)} ({len(self.dataframe)} rows)")
            # Get numerical columns and populate the dropdown menus
            cols = self.dataframe.select_dtypes(include=np.number).columns.tolist()
            self.x_combo.clear(); self.y_combo.clear()
            self.x_combo.addItems(cols); self.y_combo.addItems(cols)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load file:\n\n{e}")

    # This is the core logic function where the heavy lifting happens
    def run_analysis(self):
        if self.dataframe is None: QMessageBox.warning(self, "Error", "Please load a CSV file first."); return
        features = [self.x_combo.currentText(), self.y_combo.currentText()]
        if not all(features): QMessageBox.warning(self, "Error", "Please select features for both axes."); return
        
        # --- SOLUTION FOR "APP NOT RESPONDING" ---
        # If the dataset is too large, run the analysis on a smaller random sample
        max_points_for_analysis = 30000
        if len(self.dataframe) > max_points_for_analysis:
            # Update the UI to let the user know what's happening
            self.results_label.setText(f"Dataset is large. Running analysis on a random sample of {max_points_for_analysis} points...")
            QApplication.processEvents() # Force the UI to repaint *before* starting the long task
            analysis_df = self.dataframe.sample(n=max_points_for_analysis, random_state=42)
        else:
            self.results_label.setText("Running analysis..."); QApplication.processEvents()
            analysis_df = self.dataframe.copy() # Use a copy to avoid changing the original dataframe
        
        # Prepare the data for the model
        X = analysis_df[list(set(features))].values
        X_scaled = StandardScaler().fit_transform(X) # Scale data for SVM and DBSCAN
        
        # Dynamically choose and run the selected model
        model_name = self.controller.app_state.get('interactive_model')
        if model_name == 'lof':
            model = LocalOutlierFactor(contamination='auto')
            analysis_df['anomaly'] = model.fit_predict(X)
            analysis_df['score'] = model.negative_outlier_factor_
        elif model_name == 'svm':
            model = OneClassSVM(nu=0.1) # nu is the expected outlier ratio
            analysis_df['anomaly'] = model.fit_predict(X_scaled)
            analysis_df['score'] = model.decision_function(X_scaled)
        elif model_name == 'dbscan':
            model = DBSCAN(eps=0.5, min_samples=5) # eps is the max distance between points in a neighborhood
            analysis_df['anomaly'] = model.fit_predict(X_scaled)
            # DBSCAN doesn't have a 'score', so we create one for consistency (-1 for anomalies)
            analysis_df['score'] = [1 if lbl != -1 else -1 for lbl in analysis_df['anomaly']]
        
        # Call helper methods to display the results
        self.plot_results(analysis_df, features)
        self.generate_explanations(analysis_df, features, model_name)

    # Displays the scatter plot
    def plot_results(self, analysis_df, features):
        self.figure.clear(); ax = self.figure.add_subplot(111)
        # Separate the data into normal points (inliers) and anomalies (outliers)
        inliers = analysis_df[analysis_df['anomaly'] != -1]
        outliers = analysis_df[analysis_df['anomaly'] == -1]
        
        # Update the status label with the results
        status_text = f"Analysis Complete: Detected {len(outliers)} anomalies."
        if len(self.dataframe) > len(analysis_df): status_text += f" (from a sample of {len(analysis_df)} points)"
        self.results_label.setText(status_text)
        
        # Create the scatter plot
        ax.scatter(inliers[features[0]], inliers[features[1]], c='skyblue', label='Normal', alpha=0.7)
        if not outliers.empty: ax.scatter(outliers[features[0]], outliers[features[1]], c='red', marker='x', label='Anomaly')
        
        # Set plot labels and title
        ax.set_xlabel(features[0]); ax.set_ylabel(features[1]); ax.set_title(f"Detection with {self.controller.app_state.get('interactive_model').upper()}"); ax.legend(); ax.grid(True); self.figure.tight_layout(); self.canvas.draw()
        
    # Displays the text explanations for the results
    def generate_explanations(self, analysis_df, features, model_name):
        outliers = analysis_df[analysis_df['anomaly'] == -1]
        inliers = analysis_df[analysis_df['anomaly'] != -1]
        
        # Start with some basic HTML styling for the text
        html = f"""
        <style> body {{ font-family: Arial; font-size: 11pt; }} h3 {{ color: #003366; }} b {{ color: #cc0000; }} li {{ margin-bottom: 5px; }} </style>
        <h3>How {model_name.upper()} Works</h3>
        """

        # Provide a custom explanation for each model type
        if model_name == 'lof':
            html += "<p>LOF measures local density. Anomalies are points in sparse regions with a highly negative 'outlier score'.</p><hr>"
            if not outliers.empty:
                avg_inlier_score = inliers['score'].mean()
                html += f"<h3>Detected Anomaly Details</h3><p>The average score for normal points is <b>{avg_inlier_score:.2f}</b>. Anomalies have lower scores.</p><ul>"
                # Display the top 10 most anomalous points
                for _, row in outliers.sort_values(by='score').head(10).iterrows():
                    html += f"<li>Point ({row[features[0]]:.2f}, {row[features[1]]:.2f}) has score <b>{row['score']:.2f}</b></li>"
                if len(outliers) > 10: html += "<li><i>(And others... showing top 10)</i></li>"
                html += "</ul>"
            else: html += "<p>No anomalies were detected.</p>"

        elif model_name == 'svm':
            html += "<p>One-Class SVM learns a boundary around 'normal' data. Anomalies are points outside this boundary, with a negative 'decision score'.</p><hr>"
            if not outliers.empty:
                html += "<h3>Detected Anomaly Details</h3><ul>"
                for _, row in outliers.sort_values(by='score').head(10).iterrows():
                    html += f"<li>Point ({row[features[0]]:.2f}, {row[features[1]]:.2f}) has score <b>{row['score']:.2f}</b></li>"
                if len(outliers) > 10: html += "<li><i>(And others... showing top 10)</i></li>"
                html += "</ul>"
            else: html += "<p>No anomalies were detected.</p>"

        elif model_name == 'dbscan':
            html += "<p>DBSCAN groups dense points into clusters. Anomalies are 'noise' points that do not belong to any cluster.</p><hr>"
            if not outliers.empty:
                html += "<h3>Detected Anomalies (Noise Points)</h3><ul>"
                for _, row in outliers.head(10).iterrows():
                    html += f"<li>Point ({row[features[0]]:.2f}, {row[features[1]]:.2f}) was classified as noise.</li>"
                if len(outliers) > 10: html += "<li><i>(And others... showing first 10)</i></li>"
                html += "</ul>"
            else: html += "<p>No noise points (anomalies) were detected.</p>"

        # Set the final HTML content in the text browser
        self.explanation_browser.setHtml(html)

# ==============================================================================
# SECTION 3: VISUALIZATION WORKFLOW PAGES
# ==============================================================================

# --- VISUALIZE STEP 1: LOAD DATA ---
class VisualizeLoadPage(BasePage):
    def __init__(self, controller):
        super().__init__(controller); layout = QVBoxLayout(self); layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title = QLabel("Step 1: Load a Dataset to Visualize"); title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        self.file_label = QLabel("No file loaded."); load_button = QPushButton("Browse for CSV File..."); load_button.clicked.connect(self.load_csv)
        self.next_button = QPushButton("Next"); self.next_button.setEnabled(False)
        self.next_button.clicked.connect(lambda: self.controller.show_page('VisualizeSelectPage'))
        back_button = QPushButton("Back to Home"); back_button.clicked.connect(lambda: self.controller.show_page('HomePage'))
        layout.addStretch(); layout.addWidget(title); layout.addWidget(load_button); layout.addWidget(self.file_label); layout.addWidget(self.next_button); layout.addStretch()
        layout.addWidget(back_button, alignment=Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
    def load_csv(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "*.csv");
        if not file_path: return
        try:
            df = pd.read_csv(file_path)
            # Store the loaded dataframe in the central app state
            self.controller.app_state['dataframe'] = df
            self.file_label.setText(f"Loaded: {os.path.basename(file_path)}")
            self.next_button.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load file.\n\n{e}")
            self.next_button.setEnabled(False)

# --- VISUALIZE STEP 2: SELECT COLUMNS ---
class VisualizeSelectPage(BasePage):
    def __init__(self, controller):
        super().__init__(controller); layout = QVBoxLayout(self); layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title = QLabel("Step 2: Choose Columns to Plot"); title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        self.x_combo = QComboBox(); self.y_combo = QComboBox()
        plot_button = QPushButton("Generate Plot"); plot_button.clicked.connect(self.go_to_plot)
        back_button = QPushButton("Back"); back_button.clicked.connect(lambda: self.controller.show_page('VisualizeLoadPage'))
        layout.addStretch(); layout.addWidget(title); layout.addWidget(QLabel("X-Axis:")); layout.addWidget(self.x_combo)
        layout.addWidget(QLabel("Y-Axis:")); layout.addWidget(self.y_combo); layout.addWidget(plot_button); layout.addStretch()
        layout.addWidget(back_button, alignment=Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
    def on_show(self):
        # Get the dataframe from the central app state and populate dropdowns
        df = self.controller.app_state.get('dataframe');
        if df is None: return
        cols = df.select_dtypes(include=np.number).columns.tolist()
        self.x_combo.clear(); self.y_combo.clear()
        self.x_combo.addItems(cols); self.y_combo.addItems(cols)
    def go_to_plot(self):
        # Store the selected columns in the central app state before switching pages
        self.controller.app_state['vis_x_col'] = self.x_combo.currentText()
        self.controller.app_state['vis_y_col'] = self.y_combo.currentText()
        self.controller.show_page('VisualizePlotPage')

# --- VISUALIZE STEP 3: SHOW PLOT ---
class VisualizePlotPage(BasePage):
    def __init__(self, controller):
        super().__init__(controller); layout = QVBoxLayout(self)
        self.status_label = QLabel(); self.figure = Figure(); self.canvas = FigureCanvas(self.figure)
        start_over_button = QPushButton("Start Over"); start_over_button.clicked.connect(lambda: self.controller.show_page('HomePage'))
        layout.addWidget(self.status_label); layout.addWidget(self.canvas); layout.addWidget(start_over_button, alignment=Qt.AlignmentFlag.AlignCenter)
    def on_show(self):
        # Retrieve all necessary data from the central app state
        df = self.controller.app_state.get('dataframe')
        x_col = self.controller.app_state.get('vis_x_col')
        y_col = self.controller.app_state.get('vis_y_col')

        if df is None or not x_col or not y_col: return

        # Sample the data if it's too large to plot quickly
        max_points_to_plot = 50000
        if len(df) > max_points_to_plot:
            self.status_label.setText(f"Dataset is large ({len(df)} rows). Plotting a random sample of {max_points_to_plot} points.")
            plot_df = df.sample(n=max_points_to_plot, random_state=42)
        else:
            self.status_label.setText("")
            plot_df = df
        
        # Create the plot
        self.figure.clear(); ax = self.figure.add_subplot(111)
        ax.scatter(plot_df[x_col], plot_df[y_col], alpha=0.6)
        ax.set_xlabel(x_col); ax.set_ylabel(y_col); ax.set_title(f"{y_col} vs. {x_col}"); ax.grid(True)
        self.figure.tight_layout(); self.canvas.draw()

# --- Application Entry Point ---
# This is the standard boilerplate to run a PyQt6 application
if __name__ == "__main__":
    app = QApplication(sys.argv) # Create the application instance
    controller = AppController()   # Create the main window
    controller.show()              # Show the window
    sys.exit(app.exec())           # Start the application's event loop